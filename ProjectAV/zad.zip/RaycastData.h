#pragma once

#include "Collider.h"

class Collider;

class RaycastData
{
public:
	RaycastData(Collider* hitCollider, Vector3 hitPoint) : hitCollider(hitCollider), hitPoint(hitPoint) {}
	Collider* hitCollider;
	Vector3 hitPoint;
};