#pragma once

#define noxnd noexcept(!IS_DEBUG)