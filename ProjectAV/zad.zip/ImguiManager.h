#pragma once

class ImguiManager
{
public:
	ImguiManager();
	~ImguiManager();
};
