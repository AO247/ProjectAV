#pragma once
#include "Graphics.h"

void TestDynamicConstant();

void TestDynamicMeshLoading();

void TestMaterialSystemLoading( Graphics& gfx );

void TestScaleMatrixTranslation();