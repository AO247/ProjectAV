#pragma once

enum Layers
{
	NONE = 0,
	PLAYER = 1,
	GROUND = 2,
	ENEMY = 3
};