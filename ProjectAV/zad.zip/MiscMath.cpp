/*#include <SimpleMath.h>

float MaxVectorElementValue(DirectX::SimpleMath::Vector3& vector)
{
	float max = vector.x;

	if (vector.y > max)
	{
		max = vector.y;
	}
	if (vector.z > max)
	{
		max = vector.z;
	}

	return max;
}*/